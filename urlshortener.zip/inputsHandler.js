let idCounter = 63;
const urlMap = new Map();

function isValidUrl(url) {
  const regex =
    /^(https?:\/\/)?([\da-z\.-]+)\.([a-z\.]{2,6})([\/\w \.-]*)*\/?$/;
  return regex.test(url);
}

function to_base_62(deci) {
  var hash_str, s;
  s = "012345689abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
  hash_str = "";

  while (deci > 0) {
    var b = parseInt(deci % 62);
    var a = s[b] ? s[b] : "";
    hash_str = hash_str + a;
    deci = parseInt(deci / 62);
    console.log("b", b, "a", a, "deci", deci);
  }
  const shortURL = `http://short.tu/${hash_str}`;

  return { shortURL, hash_str };
}

// Function to shorten a URL
function shortenURL(longUrl) {
  if (isValidUrl(longUrl)) {
    const { shortURL, hash_str } = to_base_62(idCounter++);
    urlMap.set(hash_str, longUrl);
    console.log(shortURL);
    return shortURL; // This is the 'short' URL
  }
  else return('Not A Valid URL');
}

function getLongUrl(id) {
  console.log(id);
  if (urlMap.has(id)) {
    console.log(urlMap.get(id));
    return urlMap.get(id);
  }

  return { error: "Key not found" };
}

module.exports = { getLongUrl, to_base_62, shortenURL };
